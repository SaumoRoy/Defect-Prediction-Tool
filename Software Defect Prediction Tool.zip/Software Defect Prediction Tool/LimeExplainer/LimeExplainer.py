import lime
import lime.lime_tabular
import pandas as pd
import pickle
import os
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

def lime_explainer(csv_loc): 
    variables = {}
    
    all_data = pd.read_csv(csv_loc[0])
    for _, row in all_data.iterrows():
        variables[row.values[0]] = row.values[1]
        
    training_data = pd.read_csv(variables["training_data"])
    testing_data = pd.read_csv(variables["testing_data"])
    target_col = variables["target_col"]
    training_data[target_col] = pd.Categorical(training_data[target_col])
    training_data[target_col] = training_data[target_col].cat.codes

    testing_data[target_col] = pd.Categorical(testing_data[target_col])
    testing_data[target_col] = testing_data[target_col].cat.codes
    
    features = variables["features"].split(",")
    
    X_train = training_data.loc[:, features]
    X_test = testing_data.loc[:, features]

    y_train = training_data.loc[:, target_col]
    class_labels = variables["class_labels"]
    file_to_be_explained = int(variables["file_to_be_explained"])
    our_model_rf_loc = variables["our_rf_model_loc"]
    our_rf_model = pickle.load(open(our_model_rf_loc, 'rb'))
    # LIME Step 1 - Construct an explainer
    our_lime_explainer = lime.lime_tabular.LimeTabularExplainer(
                                training_data = X_train.values,  
                                mode = 'classification',
                                training_labels = y_train,
                                feature_names = features,
                                class_names = class_labels,
                                discretize_continuous = True)
                                
    # LIME Step 2 - Use the constructed explainer with the predict function 
    # of your predictive model to explain any instance

    lime_local_explanation_of_an_instance = our_lime_explainer.explain_instance(
                                data_row = X_test.loc[file_to_be_explained, : ],
                                predict_fn = our_rf_model.predict_proba, 
                                num_features = 5,
                                top_labels = 1
                                )

    # Please use the code below to visualise the generated LIME explanation.
    # plt.savefig("image.png", lime_local_explanation_of_an_instance.as_pyplot_figure())
    bar = lime_local_explanation_of_an_instance.as_pyplot_figure(label=1)
    plt.savefig("lime_output.png", bbox_inches="tight")
    
    return os.path.abspath("lime_output.png")

if __name__ == "__main__":
    import argparse
    import sys
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('all_data', nargs="+", type=str)
        args = parser.parse_args()
        sum = lime_explainer(args.all_data)
        sys.stdout.write(sum)
        sys.stdout.flush()
    except Exception as e:
        sys.stderr.write(str(e))

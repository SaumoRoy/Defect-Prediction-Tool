from os import path
thispath = path.abspath(path.dirname(__file__))

def demo_service(context, *args, **kwargs):
	arguments = context.parse_args('test_lime_explainer', '', *args, **kwargs)
	print("in adapter")
	print(arguments)
	out, err = context.pyvenv_run_at_venv(thispath, 
                                       "python", 
                                       '1/random_forest_env', 
                                       path.join(thispath, 'LimeExplainer.py'), 
                                       arguments["data"])
	if err:
		raise(f"Tool test_lime_explainer exited with error: {err}")
	return out
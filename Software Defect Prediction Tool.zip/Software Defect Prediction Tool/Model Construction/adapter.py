from os import path
thispath = path.abspath(path.dirname(__file__))

def demo_service(context, *args, **kwargs):
	arguments = context.parse_args('test_sklearn1', '', *args, **kwargs)
	print("in adapter")
	print(arguments)
	out, err = context.pyvenv_run_at_venv(thispath, 
                                       "python", 
                                       '1/random_forest_env', 
                                       path.join(thispath, 'random_forest_model_train.py'), 
                                       arguments["data"])
	if err:
		raise(f"Tool test_sklearn1 exited with error: {err}")
	return out
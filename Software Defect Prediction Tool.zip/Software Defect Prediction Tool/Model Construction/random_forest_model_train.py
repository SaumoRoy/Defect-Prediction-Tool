from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import pickle
import os
import argparse
import sys

def train_rf(train_df):
    all_data = train_df[0].split("$")
    features = all_data[2].split(",")
    target_col = all_data[1]
    train_dataset = pd.read_csv(all_data[0])
    X_train = train_dataset.loc[:, features]
    y_train = train_dataset.loc[:, target_col]
    our_rf_model = RandomForestClassifier(random_state=0)
    our_rf_model.fit(X_train, y_train)  
    filename = 'finalized_model.sav'
    pickle.dump(our_rf_model, open(filename, 'wb'))
    return os.path.abspath('finalized_model.sav')



if __name__ == "__main__":
    import argparse
    import sys
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('all_data', nargs="+", type=str)
        args = parser.parse_args()
        sum = train_rf(args.all_data)
        sys.stdout.write(str(sum))
        sys.stdout.flush()
    except Exception as e:
        sys.stderr.write(str(e))
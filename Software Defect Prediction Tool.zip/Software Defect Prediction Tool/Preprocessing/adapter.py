from os import path
thispath = path.abspath(path.dirname(__file__))
from .preprocessing import preprocessing
def demo_service(context, *args, **kwargs):
    arguments= context.parse_args("saumo_da_preprocessing_test1", '', *args,**kwargs )
    out= preprocessing(arguments["data1"],arguments["data2"],arguments["data3"], arguments["data4"])
    return out
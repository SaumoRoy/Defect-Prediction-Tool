
import pandas as pd
import os

def preprocessing(train_file, test_file, features, target_col, index_col='File'):

    train_dataset = pd.read_csv(train_file, index_col = index_col)
    test_dataset = pd.read_csv(test_file, index_col = index_col)

    # target_col = 'RealBug'
    # features = ['OWN_COMMIT', 'Added_lines', 'CountClassCoupled', 'AvgLine', 'RatioCommentToCode', 'CountLine']
    # commits - # of commits that modify the file of interest
    # Added lines - # of added lines of code
    # Count class coupled - # of classes that interact or couple with the class of interest
    # LOC - # of lines of code
    # RatioCommentToCode - The ratio of lines of comments to lines of code

    # process outcome to 0 and 1
    train_dataset[target_col] = pd.Categorical(train_dataset[target_col])
    train_dataset[target_col] = train_dataset[target_col].cat.codes

    test_dataset[target_col] = pd.Categorical(test_dataset[target_col])
    test_dataset[target_col] = test_dataset[target_col].cat.codes

    X_train = train_dataset.loc[:, features]
    X_test = test_dataset.loc[:, features]

    y_train = train_dataset.loc[:, target_col]
    y_test = test_dataset.loc[:, target_col]

    X_train.columns = features
    X_test.columns = features
    training_data = pd.concat([X_train, y_train], axis=1)
    testing_data = pd.concat([X_test, y_test], axis=1)

    training_data.to_csv("training_data.csv", index=False)
    testing_data.to_csv("testing_data.csv", index=False)

    return [os.path.abspath("training_data.csv"), os.path.abspath("testing_data.csv")]
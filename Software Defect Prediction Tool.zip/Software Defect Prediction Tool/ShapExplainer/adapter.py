from os import path
thispath = path.abspath(path.dirname(__file__))

def demo_service(context, *args, **kwargs):
	arguments = context.parse_args('test_shap_explainer', '', *args, **kwargs)
	print("in adapter")
	print(arguments)
	out, _ = context.pyvenv_run_at_venv(thispath, 
                                       "python", 
                                       '1/random_forest_env', 
                                       path.join(thispath, 'shap_explainer.py'), 
                                       arguments["data"])
	return out
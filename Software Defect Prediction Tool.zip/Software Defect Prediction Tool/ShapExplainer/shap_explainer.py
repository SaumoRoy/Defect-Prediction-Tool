import shap
import pandas as pd
import os
import pickle
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")


def shap_explainer(csv_loc):
    variables = {}
    
    all_data = pd.read_csv(csv_loc[0])
    for _, row in all_data.iterrows():
        variables[row.values[0]] = row.values[1]
    features = variables["features"].split(",")
    testing_data = pd.read_csv(variables["testing_data"])
    our_model_rf_loc = variables["our_rf_model_loc"]
    our_rf_model = pickle.load(open(our_model_rf_loc, 'rb'))
    
    X_test = testing_data.loc[:, features]

    file_to_be_explained = int(variables["file_to_be_explained"])
    # SHAP Step 1 - Construct an explainer with the predict function
    # of your predictive model
    our_shap_explainer = shap.KernelExplainer(our_rf_model.predict, X_test)
                                
    # SHAP Step 2 - Generate the SHAP explanation of an instance to be explained
    shap_explanations_of_an_instance = our_shap_explainer.shap_values(X_test.iloc[file_to_be_explained, :])
                                
    # Please use the code below to visualise the generated SHAP explanation (Force plot).
    shap.initjs()
    shap_force = shap.force_plot(our_shap_explainer.expected_value, 
                    shap_explanations_of_an_instance, 
                    X_test.iloc[file_to_be_explained,:])
    shap.save_html('shap_force_plot.html', shap_force)
    shap_bar = shap.bar_plot(shap_explanations_of_an_instance, show=False)
    plt.savefig('shap_bar_plot.png', bbox_inches="tight")
    
    
    return [os.path.abspath("shap_force_plot.html"), os.path.abspath("shap_bar_plot.png")]


if __name__ == "__main__":
    import argparse
    import sys
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument('all_data', nargs="+", type=str)
        args = parser.parse_args()
        sum = shap_explainer(args.all_data)
        sys.stdout.write(sum)
        sys.stdout.flush()
    except Exception as e:
        sys.stderr.write(str(e))